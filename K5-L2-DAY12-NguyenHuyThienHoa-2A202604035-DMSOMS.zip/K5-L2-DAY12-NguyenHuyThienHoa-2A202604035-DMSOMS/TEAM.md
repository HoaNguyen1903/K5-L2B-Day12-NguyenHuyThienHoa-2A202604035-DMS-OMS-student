# TEAM — Ngày 12

Mã bộ ảnh: **G11** · Hình thức: cá nhân

| Họ tên | MSSV | Đã gán đủ 22 ảnh? | Review chéo với (peer diff) | Số dòng disagreement đã xử lý |
|---|---|---|---|---|
| Nguyễn Huy Thiên Hòa | 2A202604035 | có | Nguyễn Thế Tùng - 2A202603320 (03320) | 71 |

Ca hai bạn vẫn không thống nhất và đã hỏi coach (ghi tên ảnh + đối tượng):

- D04 tài xế: Thuộc tính `eye_left` / `eye_right` khi tài xế cúi đầu trong góc tối (chọn unknown hay open).
- S03/S04/S07: Thuộc tính `occupied='yes'` trên ghế trẻ em (được giảng viên cho phép sử dụng ngoại lệ so với guideline gốc).

## Cá nhân

Mỗi người một mục, 1–2 dòng mỗi ý.

### NguyenHuyThienHoa-2A202604035
- Phần mình làm: Gán toàn bộ 22 ảnh bộ G11 trên CVAT, thực hiện review chéo diff với bạn Nguyễn Thế Tùng (03320) cùng mã bộ ảnh G11 (xử lý 71 dòng bất đồng), giữ nguyên thuộc tính occupied='yes' theo thông báo của giảng viên trên lớp, hoàn thiện danh sách lớp v0 và exit ticket.
- Điều mình học được hôm nay: Hiểu sâu sắc sự khác biệt giữa chuẩn guideline lý thuyết và các ngoại lệ thực tế theo yêu cầu khách hàng/giảng viên; nắm vững hệ quy chiếu ghế theo xe (trái ảnh là phải xe) và trục mắt theo cơ thể người khi ảnh xoay 90 độ.
