# Tự đánh giá — Nguyễn Huy Thiên Hòa · G11

## 1. Tự rà soát 4 cảnh

Nghỉ tay 1 phút, mở lại bài của mình, chọn 4 ảnh (2 S##, 2 D##), đọc như người lạ.

Loại lỗi: `seat_flip`, `wrong_class`, `guess`, `box`, `missing`, `extra`, `lr_flip` (trái/phải mặt), `flag` (thiếu cờ điểm), `ok`.

| Ảnh | Đối tượng | Loại lỗi | Ghi chú | Đã sửa? |
|---|---|---|---|---|
| S01_rgb | person (rear_right) | ok | Đã kiểm tra ghế theo xe (trái ảnh là rear_right), seatbelt=not_worn | Đã kiểm |
| S03_ir | object (rear_left) | ok | Box ôm sát vật thể, phân loại đúng type=bag/box | Đã kiểm |
| D01 | face13 | ok | Đã kiểm tra trục y: left_eye có y lớn hơn right_eye trên ảnh xoay 90° | Đã kiểm |
| D02 | hand (driver) | ok | Gán đúng side theo tay người lái, on_wheel=no chính xác cho xe tự hành | Đã kiểm |

## 2. Lỗi mình lặp lại nhiều nhất hôm nay

Lỗi: Thói quen quán tính quy ước trái/phải theo góc nhìn người xem ảnh thay vì theo hệ quy chiếu của xe và của cơ thể người.

Vì sao mình mắc: Do camera OMS nhìn ngược từ trước ra sau (làm đảo ngược trái/phải ảnh so với xe) và ảnh DMS bị xoay 90° nên trực giác quan sát ban đầu dễ bị nhầm.

Lần sau tránh bằng cách: Luôn tự nhủ nguyên tắc 'đặt mình vào vị trí người ngồi trong xe nhìn về phía trước' cho OMS, và 'nghiêng đầu 90° theo chiều ảnh để xác định mắt trái/tay trái của người' cho DMS trước khi chọn thuộc tính.

## 3. Ghi chú về disagreement_log

Một dòng bạn của mình đúng và mình sai. Mình học được gì từ dòng đó: Ở ảnh D03, bạn Nguyễn Thế Tùng (03320) phát hiện điểm khóe mắt bị che khuất một phần dưới gọng kính cần đánh cờ `occluded=1` thay vì để `0`. Tôi học được rằng việc đánh cờ che khuất (occlusion flag) cực kỳ quan trọng để mô hình AI không học sai vị trí mốc giải phẫu khi bị ngoại vật cản trở.
