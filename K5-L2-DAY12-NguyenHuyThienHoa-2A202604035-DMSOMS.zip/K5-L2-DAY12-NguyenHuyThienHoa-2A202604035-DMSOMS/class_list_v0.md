# Danh sách lớp v0 — Nguyễn Huy Thiên Hòa · G11

Viết tiếp từ slide 54 bài giảng. Mỗi lớp trả lời: **model cần nhận ra cái này để làm gì?**

## DMS (ít nhất 6 lớp)

| # | Lớp / thuộc tính | Giá trị | Để làm gì (chức năng DMS) | Nhìn thấy được trên IR? |
|---|---|---|---|---|
| 1 | eye_state | open / closed / unknown | Phát hiện tài xế buồn ngủ (mắt nhắm kéo dài theo ngưỡng PERCLOS) hoặc ngủ gật | Có, nhờ đèn NIR chiếu sáng ban đêm; trừ trường hợp phản xạ đèn LED lóa tròng kính |
| 2 | gaze_zone | road / mirror_l / mirror_r / mirror_c / cluster / center / lap / other | Phát hiện mất tập trung thị giác (visual distraction) khi mắt không hướng về phía mặt đường (road) > 2-3s | Có, xác định qua góc đồng tử và hướng mắt |
| 3 | head_pose | yaw, pitch, roll | Bổ trợ cho gaze_zone khi mắt bị che/kính râm; phát hiện gục đầu (drowsiness) hoặc quay đầu nói chuyện | Có, dựa trên hình thái khuôn mặt và các mốc keypoint |
| 4 | hands_on_wheel | yes / no / unknown | Giám sát mức độ sẵn sàng tiếp quản quyền lái xe (Take-Over Readiness) trong xe tự hành L2/L3 | Có, nhận diện bàn tay chạm vào vành vô lăng |
| 5 | phone_interaction | held / mounted / lap | Cảnh báo hành vi phân tâm nguy hiểm (sử dụng điện thoại khi đang điều khiển phương tiện theo Euro NCAP) | Có, qua hình dáng chữ nhật, góc cạnh phản xạ ánh sáng |
| 6 | seatbelt_driver | worn_correct / worn_incorrect / not_worn / unknown | Cảnh báo thắt dây an toàn cho tài xế và kích hoạt thuật toán bung túi khí phù hợp | Có thể thấy dải dây chéo qua ngực, nhưng trên nền áo tối có thể giảm tương phản |

## OMS (ít nhất 6 lớp)

| # | Lớp / thuộc tính | Giá trị | Để làm gì (chức năng OMS) | Nhìn thấy được trên IR? |
|---|---|---|---|---|
| 1 | seat_occupancy | empty / person / object / child_seat / infant_seat | Quản lý tải trọng hàng ghế sau, bật/tắt nhắc thắt dây an toàn và điều chỉnh lực bung túi khí tương ứng | Có, phân biệt rõ qua hình dạng và độ nổi khối 3D |
| 2 | infant_seat_facing | rear / front | Điều khiển túi khí thông minh (Smart Airbag Suppression): cấm bung túi khí trước nếu ghế em bé quay ngược | Có, nhận diện qua hướng quai xách và chiều vát của nôi |
| 3 | child_seat_occupancy | no / unknown | Phát hiện trẻ em ngồi trong ghế để kích hoạt hệ thống giám sát trẻ em (Child Presence Detection - CPD) | Có, nhận dạng hình dáng trẻ ngồi trong lòng ghế |
| 4 | unattended_object | bag / box / cup / other | Cảnh báo bỏ quên hành lý có giá trị khi tài xế khóa cửa rời xe (Forgotten Object Detection) | Có, dựa trên hình khối hộp/túi trên mặt đệm ghế |
| 5 | seatbelt_rear | worn_correct / worn_incorrect / not_worn / unknown | Cảnh báo nhắc thắt dây an toàn cho từng hành khách ngồi hàng ghế sau (Seatbelt Reminder - SBR) | Có trên ảnh thực; với IR-sim SVIRO luôn là not_worn/unknown |
| 6 | passenger_out_of_position | in_position / out_of_position | Điều chỉnh lực nổ túi khí rèm và túi khí hông để tránh gây chấn thương cho hành khách ngồi sai tư thế | Có, phân định qua box person và vùng không gian chiếm dụng |

## 2 câu hỏi leo thang

Câu hỏi bạn muốn hỏi người viết guideline (hoặc khách hàng) vì guideline v1.0 chưa trả lời. Mỗi câu kèm **tên khung** làm ví dụ.

1. Câu hỏi: Khi hành khách/tài xế mặc áo khoác dày tối màu trùng với màu ghế hoặc trong điều kiện IR-sim/NIR ánh sáng biên yếu, ranh giới giữa thân người (`person`) và đệm lưng ghế rất khó phân biệt chính xác pixel viền ngoài. Có nên quy định vẽ bounding box sát phần cơ thể chắc chắn nhìn thấy hay vẽ bao quát cả thể tích ước lượng dựa trên phom ghế?
   Khung ví dụ: S05_ir (khung hồng ngoại mô phỏng hàng ghế sau G11)
   Bạn tạm gán thế nào và vì sao: Tạm thời gán box ôm sát phần cơ thể tương phản rõ rệt nhất, thuộc tính seatbelt để `unknown` do bóng tối che khuất, tuân thủ đúng Quy tắc chung 1 (Không thấy thì unknown) và Quy tắc chung 5 (Hộp sát mép phần thấy được).

2. Câu hỏi: Trong khung hình tài xế xoay 90° (Drive&Act NIR), khi tài xế đeo kính gọng dày và đèn LED phát xạ tạo đốm chói lóa (specular reflection) che phủ hoàn toàn 1 con mắt nhưng thấy rõ gọng kính đang nằm trên sống mũi, thuộc tính `glasses` nên ghi là `clear` (kính cận bình thường) hay `unknown`?
   Khung ví dụ: D02 (khung tài xế đeo kính có đốm phản xạ NIR)
   Bạn tạm gán thế nào và vì sao: Tạm gán `glasses = clear` vì gọng kính và tròng nhìn xuyên một phần thấy rõ, nhưng hai thuộc tính `eye_left` / `eye_right` thì con mắt bị đốm chói che phủ bắt buộc gán `unknown`, 4 điểm keypoint mắt tương ứng bật cờ `occluded = 1` để không gây nhiễu cho model nhận diện đóng/mở mắt.
