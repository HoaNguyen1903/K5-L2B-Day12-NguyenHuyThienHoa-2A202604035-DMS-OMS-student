# Khai báo dùng AI — Nguyễn Huy Thiên Hòa

Nhắc lại: không đưa ảnh cabin hay ảnh tài xế (kể cả ảnh chụp màn hình) cho bất kỳ công cụ AI nào.

| # | Công cụ | Bạn hỏi gì (tóm tắt) | Bạn dùng kết quả thế nào | Bạn có kiểm lại không? Bằng gì? |
|---|---|---|---|---|
| 1 | Antigravity AI Assistant | Giải thích quy ước tọa độ và ma trận trục xoay 90° của ảnh Drive&Act NIR và thứ tự ghế xe BMW X5 trong SVIRO | Hiểu rõ trục mắt (mắt trái có y lớn hơn trên ảnh xoay) và camera OMS nhìn lùi (trái ảnh = rear_right) | Kiểm tra trực tiếp bằng script `cabin_check.py` và GUIDE.md |
| 2 | Antigravity AI Assistant | Hỗ trợ tự động thiết lập Project Day12 và Task Day12-G11 với 22 ảnh cốt lõi trên CVAT REST API | Tiết kiệm thời gian import dữ liệu, đảm bảo không chọn nhầm S09/S10/manifest | Kiểm tra danh sách task trên giao diện CVAT localhost:8080 |
| 3 | Antigravity AI Assistant | Soạn thảo dự thảo danh sách nhãn DMS/OMS theo chuẩn an toàn Euro NCAP (Task 4) | Điền vào `class_list_v0.md` với đầy đủ chức năng và câu hỏi leo thang | Tự đọc soát và đối chiếu slide 40-54 |
